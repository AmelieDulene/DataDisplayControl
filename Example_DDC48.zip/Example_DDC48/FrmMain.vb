﻿Imports System.IO
Imports DataDisplayControl48

Public Class FrmMain

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        myDDC1.Title = "DDC-Example Version: 3.0.1.3"
    End Sub

    ' ---------------- Demo Buttons ----------------
    Private Sub BtnAddItems_Click(sender As Object, e As EventArgs) Handles BtnAddItems.Click
        AddItemsExample()
    End Sub

    Private Sub BtnUpdateItems_Click(sender As Object, e As EventArgs) Handles BtnUpdateItems.Click
        UpdateItemsExample()
    End Sub

    Private Sub BtnGetDrives_Click(sender As Object, e As EventArgs) Handles BtnGetDrives.Click
        GetInstalledDrives()
    End Sub

    ' ---------------- Demo Methoden ----------------
    Public Sub AddItemsExample()
        BtnUpdateItems.Enabled = True
        myDDC1.Title = "DDC-Example-ADD"
        myDDC1.ClearInfoItems()

        ' Beispiel-Items
        myDDC1.AddInfoItem("Temperatur", "25.4", "°C")
        myDDC1.AddInfoItem("Luftfeuchte", "45", Color.Green, "%")
        myDDC1.AddInfoItem("System-Last", "98", Color.Red, "%")
    End Sub

    Public Sub UpdateItemsExample()
        myDDC1.Title = "DDC-Example-Update"
        myDDC1.UpdateInfoItem("Temperatur", "25.9")
        myDDC1.UpdateInfoItem("System-Last", "75", Color.Blue)
        myDDC1.UpdateInfoItem(1, "48", "g/m³")
    End Sub

    ' Farben dynamisch setzen – DEMO, Schwellenwerte anpassbar
    Private Function GetDriveColor(freeGB As Double, totalGB As Double) As Color
        If totalGB <= 0 Then Return Color.DarkGray
        Dim usagePercent As Double = (totalGB - freeGB) / totalGB * 100

        If usagePercent < 40 Then
            Return Color.Green
        ElseIf usagePercent < 50 Then
            Return Color.Orange
        Else
            Return Color.Red
        End If
    End Function

    ' ---------------- Laufwerke anzeigen ----------------
    Private Sub GetInstalledDrives()
        BtnUpdateItems.Enabled = False
        myDDC1.Title = "DDC-Get-Drives"
        myDDC1.ClearInfoItems()

        ' Headline
        myDDC1.AddInfoItem("Name / Beschreibung", "Wert", Color.Black, "Einheit")

        ' Laufwerke
        For Each d As DriveInfo In DriveInfo.GetDrives()
            Try
                Dim freeGB As Double = Math.Round(d.AvailableFreeSpace / (1024 ^ 3), 1)
                Dim totalGB As Double = Math.Round(d.TotalSize / (1024 ^ 3), 1)
                Dim statusColor As Color = GetDriveColor(freeGB, totalGB)

                myDDC1.AddInfoItem(d.Name, $"{freeGB} / {totalGB}", statusColor, "GB")
            Catch ex As Exception
                myDDC1.AddInfoItem(d.Name, "nicht verfügbar", Color.Red, "")
            End Try
        Next

        ' Sicherstellen, dass Control gezeichnet wird
        Me.Controls.Add(myDDC1)
    End Sub

    ' ---------------- Klick-Handler ----------------
    ' SingleClick – Headline (Index 0) ignorieren
    Private Sub myDDC1_ItemClick(sender As Object, e As InfoItemEventArgs) Handles myDDC1.ItemClick
        If e.Index = 0 Then Return
        MessageBox.Show($"SingleClick auf Item '{e.Item.Label}' (Index {e.Index})",
                        "SingleClick",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information)
    End Sub

    ' DoubleClick – Explorer öffnen, Headline ignorieren
    Private Sub myDDC1_ItemDoubleClick(sender As Object, e As InfoItemEventArgs) Handles myDDC1.ItemDoubleClick
        If e.Index = 0 Then Return
        Try
            Dim path As String = e.Item.Label
            If Directory.Exists(path) OrElse File.Exists(path) Then
                Process.Start("explorer.exe", path)
            Else
                MessageBox.Show($"Pfad nicht gefunden: {path}", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("Fehler beim Öffnen: " & ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class