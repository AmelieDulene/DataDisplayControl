﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.myDDC1 = New DataDisplayControl48.DataDisplayControl()
        Me.BtnAddItems = New System.Windows.Forms.Button()
        Me.BtnUpdateItems = New System.Windows.Forms.Button()
        Me.BtnGetDrives = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'myDDC1
        '
        Me.myDDC1.BackgroundColor = System.Drawing.Color.Transparent
        Me.myDDC1.BorderColor = System.Drawing.Color.Blue
        Me.myDDC1.BorderRadius = 8.0!
        Me.myDDC1.BorderWidth = 1.5!
        Me.myDDC1.HoverBorderColor = System.Drawing.Color.SteelBlue
        Me.myDDC1.ItemFont = New System.Drawing.Font("Consolas", 9.0!)
        Me.myDDC1.ItemHoverColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(196, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.myDDC1.LabelColor = System.Drawing.Color.FromArgb(CType(CType(96, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.myDDC1.Location = New System.Drawing.Point(12, 72)
        Me.myDDC1.MinimumSize = New System.Drawing.Size(170, 80)
        Me.myDDC1.Name = "myDDC1"
        Me.myDDC1.Size = New System.Drawing.Size(502, 80)
        Me.myDDC1.TabIndex = 0
        Me.myDDC1.Title = "Headline"
        Me.myDDC1.TitleColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.myDDC1.TitleFont = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.myDDC1.ValueColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        '
        'BtnAddItems
        '
        Me.BtnAddItems.Location = New System.Drawing.Point(12, 22)
        Me.BtnAddItems.Name = "BtnAddItems"
        Me.BtnAddItems.Size = New System.Drawing.Size(110, 23)
        Me.BtnAddItems.TabIndex = 1
        Me.BtnAddItems.Text = "AddItems"
        Me.BtnAddItems.UseVisualStyleBackColor = True
        '
        'BtnUpdateItems
        '
        Me.BtnUpdateItems.Location = New System.Drawing.Point(128, 22)
        Me.BtnUpdateItems.Name = "BtnUpdateItems"
        Me.BtnUpdateItems.Size = New System.Drawing.Size(110, 23)
        Me.BtnUpdateItems.TabIndex = 2
        Me.BtnUpdateItems.Text = "Update Items"
        Me.BtnUpdateItems.UseVisualStyleBackColor = True
        '
        'BtnGetDrives
        '
        Me.BtnGetDrives.Location = New System.Drawing.Point(244, 22)
        Me.BtnGetDrives.Name = "BtnGetDrives"
        Me.BtnGetDrives.Size = New System.Drawing.Size(110, 23)
        Me.BtnGetDrives.TabIndex = 3
        Me.BtnGetDrives.Text = "ShowDrives"
        Me.BtnGetDrives.UseVisualStyleBackColor = True
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(526, 346)
        Me.Controls.Add(Me.BtnGetDrives)
        Me.Controls.Add(Me.BtnUpdateItems)
        Me.Controls.Add(Me.BtnAddItems)
        Me.Controls.Add(Me.myDDC1)
        Me.Name = "FrmMain"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents myDDC1 As DataDisplayControl48.DataDisplayControl
    Friend WithEvents BtnAddItems As Button
    Friend WithEvents BtnUpdateItems As Button
    Friend WithEvents BtnGetDrives As Button
End Class
