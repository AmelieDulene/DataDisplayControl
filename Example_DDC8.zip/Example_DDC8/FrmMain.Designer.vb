﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim MyInfoItem1 As DataDisplayControl.MyInfoItem = New DataDisplayControl.MyInfoItem()
        myDDC1 = New DataDisplayControl.CustomDataPanel()
        BtnAddItems = New Button()
        BtnUpdateItems = New Button()
        BtnGetDrives = New Button()
        SuspendLayout()
        ' 
        ' myDDC1
        ' 
        myDDC1.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        myDDC1.BackgroundColor = Color.Transparent
        myDDC1.BorderColor = Color.Blue
        myDDC1.BorderRadius = 8F
        myDDC1.BorderWidth = 1.5F
        myDDC1.HoverBorderColor = Color.SteelBlue
        MyInfoItem1.Label = "Label"
        MyInfoItem1.StatusColor = Color.DarkGray
        MyInfoItem1.Unit = "Unit"
        MyInfoItem1.Value = "Value"
        myDDC1.InfoItems.Add(MyInfoItem1)
        myDDC1.ItemFont = New Font("Consolas", 9F)
        myDDC1.ItemHoverColor = Color.FromArgb(CByte(40), CByte(176), CByte(196), CByte(222))
        myDDC1.LabelColor = Color.FromArgb(CByte(96), CByte(96), CByte(96))
        myDDC1.Location = New Point(12, 51)
        myDDC1.MinimumSize = New Size(170, 80)
        myDDC1.Name = "myDDC1"
        myDDC1.Size = New Size(367, 80)
        myDDC1.TabIndex = 0
        myDDC1.Title = "Lorem Ipsum Dolores"
        myDDC1.TitleColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        myDDC1.TitleFont = New Font("Segoe UI", 11F, FontStyle.Bold)
        myDDC1.ValueColor = Color.FromArgb(CByte(32), CByte(32), CByte(32))
        ' 
        ' BtnAddItems
        ' 
        BtnAddItems.Location = New Point(12, 22)
        BtnAddItems.Name = "BtnAddItems"
        BtnAddItems.Size = New Size(75, 23)
        BtnAddItems.TabIndex = 1
        BtnAddItems.Text = "Add-Items"
        BtnAddItems.UseVisualStyleBackColor = True
        ' 
        ' BtnUpdateItems
        ' 
        BtnUpdateItems.Enabled = False
        BtnUpdateItems.Location = New Point(93, 22)
        BtnUpdateItems.Name = "BtnUpdateItems"
        BtnUpdateItems.Size = New Size(93, 23)
        BtnUpdateItems.TabIndex = 2
        BtnUpdateItems.Text = "UpDate-Items"
        BtnUpdateItems.UseVisualStyleBackColor = True
        ' 
        ' BtnGetDrives
        ' 
        BtnGetDrives.Location = New Point(192, 22)
        BtnGetDrives.Name = "BtnGetDrives"
        BtnGetDrives.Size = New Size(90, 23)
        BtnGetDrives.TabIndex = 3
        BtnGetDrives.Text = "Get-Drives"
        BtnGetDrives.UseVisualStyleBackColor = True
        ' 
        ' FrmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(391, 246)
        Controls.Add(BtnGetDrives)
        Controls.Add(BtnUpdateItems)
        Controls.Add(BtnAddItems)
        Controls.Add(myDDC1)
        FormBorderStyle = FormBorderStyle.FixedSingle
        MaximizeBox = False
        MinimizeBox = False
        Name = "FrmMain"
        StartPosition = FormStartPosition.CenterScreen
        Text = "DDC-Example Version:3.0.1.3"
        ResumeLayout(False)
    End Sub

    Friend WithEvents myDDC1 As DataDisplayControl.CustomDataPanel
    Friend WithEvents BtnAddItems As Button
    Friend WithEvents BtnUpdateItems As Button
    Friend WithEvents BtnGetDrives As Button

End Class
